import { Command } from '@heroku-cli/command';
export declare function disambiguatePipeline(pipelineIDOrName: any, command: Command): Promise<any>;
export declare function getPipeline(flags: any, command: Command): Promise<any>;
