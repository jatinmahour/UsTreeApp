export default function pollAppSetups(heroku: any, appSetups: any): Promise<any[]>;
