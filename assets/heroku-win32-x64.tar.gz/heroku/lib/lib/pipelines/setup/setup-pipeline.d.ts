export default function setupPipeline(kolkrabbi: any, app: any, settings: any, pipelineID: any, ciSettings?: any): Promise<any>;
