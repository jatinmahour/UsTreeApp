export default function getCISettings(yes: any, organization: any): Promise<{
    ci: boolean;
    organization: undefined;
}>;
