/// <reference types="node" />
import * as stream from 'stream';
declare const transform: stream.Transform;
export default transform;
