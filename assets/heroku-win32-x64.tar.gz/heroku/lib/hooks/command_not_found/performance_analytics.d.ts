import { Hook } from '@oclif/core';
declare const performance_analytics: Hook<'command_not_found'>;
export default performance_analytics;
